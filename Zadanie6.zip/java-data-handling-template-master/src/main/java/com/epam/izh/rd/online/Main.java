package com.epam.izh.rd.online;

public class Main {
}
